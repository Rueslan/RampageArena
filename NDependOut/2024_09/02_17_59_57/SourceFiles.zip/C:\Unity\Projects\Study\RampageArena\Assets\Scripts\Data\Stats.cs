﻿using System;

[Serializable]
public class Stats
{
    public float Damage;
    public float DamageRadius;
}