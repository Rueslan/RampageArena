﻿using Assets.Scripts.Data;
using Assets.Scripts.Infrastructure.Services.PersistentProgress;
using System;
using System.Collections.Generic;

[Serializable]
public class LootData: ISavedProgress
{
    public int Collected;
    public Action Changed;
    public Dictionary<string, Vector3Data> LootPositions = new();

    public void Collect(Loot loot)
    {
        Collected += loot.Value;
        Changed?.Invoke();
    }

    public void LoadProgress(PlayerProgress progress)
    {
        LootPositions = progress.WorldData.LootData.LootPositions;
        Collected = progress.WorldData.LootData.Collected;
        Changed?.Invoke();
    }

    public void UpdateProgress(PlayerProgress progress)
    {
        progress.WorldData.LootData.Collected = Collected;
        progress.WorldData.LootData.LootPositions = LootPositions;
    }
}