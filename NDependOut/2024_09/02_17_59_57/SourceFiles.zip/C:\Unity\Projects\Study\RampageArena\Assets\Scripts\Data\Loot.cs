﻿using System;

namespace Assets.Scripts.Data
{
    [Serializable]
    public class Loot
    {
        public int Value;
    }
}
