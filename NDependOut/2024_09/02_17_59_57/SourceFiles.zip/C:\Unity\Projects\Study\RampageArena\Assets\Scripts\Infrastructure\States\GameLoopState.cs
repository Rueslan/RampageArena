﻿namespace Assets.Scripts.Infrastructure.States
{
    public class GameLoopState : IState
    {
        public GameLoopState(GameStateMachine stateMachine)
        {

        }

        public void Enter()
        {
        }

        public void Exit()
        {
        }
    }
}