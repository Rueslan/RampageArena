using Assets.Scripts.Player;
using System;
using UnityEngine;

[RequireComponent(typeof(EnemyAnimator))]
public abstract class Health : MonoBehaviour
{

}
