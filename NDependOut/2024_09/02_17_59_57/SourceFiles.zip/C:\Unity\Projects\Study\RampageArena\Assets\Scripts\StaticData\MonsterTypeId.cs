public enum MonsterTypeId
{
    Lich = 0,
    Golem = 10
}
