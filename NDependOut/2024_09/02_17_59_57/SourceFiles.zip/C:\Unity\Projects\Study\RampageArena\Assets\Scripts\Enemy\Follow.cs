﻿using UnityEngine;

namespace Scripts.Enemy
{
    public abstract class Follow : MonoBehaviour
    {
    }
}