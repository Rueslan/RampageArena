﻿using System;
using System.Collections.Generic;

[Serializable]
public class KillData
{
    public List<string> ClearedSpawners = new List<string>();
}