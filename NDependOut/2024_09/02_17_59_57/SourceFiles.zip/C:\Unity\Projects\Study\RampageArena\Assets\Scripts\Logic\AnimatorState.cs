namespace Scripts.Logic
{
  public enum AnimatorState
  {
    Unknown,
    Idle,
    Attack,
    Walking,
    Died
  }
}