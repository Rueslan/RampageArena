﻿using UnityEngine;

namespace Assets.Scripts.Logic
{
    public class UniqueId : MonoBehaviour
    {
        public string Id;
    }
}
